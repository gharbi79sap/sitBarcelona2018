sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"../plugins/jquery-image-blob.min",
	'sap/m/MessageToast'
], function(Controller, JSONModel, imageblob, MessageToast) {
	"use strict";

	return Controller.extend("LeonardoDemo.controller.Home", {
		googleAPICx: "<google_search_engice_id> (cx)",
		googleAPIKey: "<google_api_key>",
		sapLeonardoAPIKey: "<sap_api_key>", 
		
		googleAPIEndPoint: "https://www.googleapis.com/customsearch/v1",
		sapLeonardoAPIEndPoint: "https://sandbox.api.sap.com/ml/prodimgclassifier/inference_sync",
		
		aImgList: {
			"ImgGoogleColelction": [],
			"ImgLeonardoCollection": []
		},
		iCounter: 0,
		productClass: true,
		productCateg: false,
		onInit: function() {
			var oModelGoogleImg = new JSONModel();
			this.getView().setModel(oModelGoogleImg);
		},
		onSearch: function(oEvent) {
			this.productClass = this.getView().byId("productClass").getSelected();
			this.productCateg = this.getView().byId("productCateg").getSelected();

			this.getView().byId("idProductsTable").setVisible(true);
			MessageToast.show("Calling Google API ...");
			if (this.productCateg) {
				this.getView().byId("idIconTabBar").setVisible(true);
			} else {
				this.getView().byId("idIconTabBar").setVisible(false);
			}
			this.googleCustomSearch();
		},
		googleCustomSearch: function() {
			var that = this;
			this.iCounter = 0;
			this.aImgList = {
				"ImgGoogleColelction": [],
				"ImgLeonardoCollection": []
			};
			var sSearchString = this.getView().byId("searchString").getValue();
			var sDateRestrict = this.getView().byId("dateRestrict").getSelectedKey();
			//var sProductClass = this.getView().byId("productClass").getSelected();
			var googleAPIEndPoint = this.googleAPIEndPoint + "?cx=" + this.googleAPICx + "&key=" + this.googleAPIKey;
			if (sSearchString !== "") {
				googleAPIEndPoint += "&q=" + sSearchString;
				if (sDateRestrict !== "") {
					googleAPIEndPoint += "&dateRestrict=" + sDateRestrict;
				}
				$.ajax({
					url: googleAPIEndPoint,
					jsonpCallback: 'processJSON',
					dataType: 'jsonp',
					success: function(result) {
						for (var key in result.items) {
							var sImg = result.items[key].pagemap.scraped;
							if (sImg !== undefined && sImg[0] !== undefined && sImg[0].image_link !== undefined && sImg[0].image_link !== "") {
								that.aImgList.ImgGoogleColelction[that.aImgList.ImgGoogleColelction.length] = {
									imgUrl: sImg[0].image_link,
									leonardoLabelVisible: false,
									leonardoLabel: "",
									leonardoScoreVisible: false,
									leonardoScore: "",
									leonardoTitle: result.items[key].title,
									leonardoDisplayLink: result.items[key].displayLink
								};
							}
						}
						that.getView().getModel().setData(that.aImgList);
						if (that.productClass) {
							MessageToast.show("Calling SAP Leonardo Product Classification API ...");
							that.leonardoProductClass();
						}
					},
					error: function(e) {
						//log error in browser
						console.log(e.message);
					}
				});
			}
		},
		leonardoProductClass: function(sUrl) {
			var that = this;
			for (var key in this.aImgList.ImgGoogleColelction) {
				var imageKey = key;
				that.convertImgToDataURLviaCanvas(imageKey, that.aImgList.ImgGoogleColelction[imageKey].imgUrl, function(imageKey, base64Img) {
					$("#__image1-__xmlview0--idProductsTable-" + imageKey).attr("src", base64Img);
					var blob = $("#__image1-__xmlview0--idProductsTable-" + imageKey).imageBlob().blob();

					var data = null;
					var data = new FormData();
					data.append("files", blob, "image" + imageKey + ".jpg");
					var xhr = new XMLHttpRequest();
					xhr.withCredentials = false;

					//setting request method
					//API endpoint for API sandbox 
					xhr.open("POST", that.sapLeonardoAPIEndPoint);

					//adding request headers
					xhr.setRequestHeader("Accept", "application/json");
					//API Key for API Sandbox
					xhr.setRequestHeader("APIKey", that.sapLeonardoAPIKey);

					xhr.addEventListener("readystatechange", function() {
						if (this.readyState === this.DONE) {
							var aLeonardo = jQuery.parseJSON(this.responseText);
							that.aImgList.ImgGoogleColelction[imageKey].leonardoLabelVisible = true;
							that.aImgList.ImgGoogleColelction[imageKey].leonardoLabel = aLeonardo.predictions[0].results[0].label;
							that.aImgList.ImgGoogleColelction[imageKey].leonardoScoreVisible = true;
							that.aImgList.ImgGoogleColelction[imageKey].leonardoScore = aLeonardo.predictions[0].results[0].score * 100;
							that.iCounter++;
							if (that.iCounter == that.aImgList.ImgGoogleColelction.length) {
								that.aImgList.ImgGoogleColelction.sort(function(a, b) {
									return b.leonardoScore - a.leonardoScore || b.leonardoScore.localeCompare(a.leonardoScore);
								});
								//
								if (that.productCateg) {
									var aCollectionLeonardo = [];
									for (var key in that.aImgList.ImgGoogleColelction) {
										var oProduct = {
											leonardoScore: that.aImgList.ImgGoogleColelction[key].leonardoScore,
											imgUrl: that.aImgList.ImgGoogleColelction[key].imgUrl,
											leonardoTitle: that.aImgList.ImgGoogleColelction[key].leonardoTitle,
											leonardoDisplayLink: that.aImgList.ImgGoogleColelction[key].leonardoDisplayLink
										};
										if (aCollectionLeonardo[that.aImgList.ImgGoogleColelction[key].leonardoLabel] === undefined) {
											aCollectionLeonardo[that.aImgList.ImgGoogleColelction[key].leonardoLabel] = {
												"Products": [oProduct]
											};
										} else {
											aCollectionLeonardo[that.aImgList.ImgGoogleColelction[key].leonardoLabel].Products.push(oProduct);
										}
									}
									for (var key in aCollectionLeonardo) {
										that.aImgList.ImgLeonardoCollection.push({
											"Label": key,
											"Products": aCollectionLeonardo[key].Products,
											"Count": aCollectionLeonardo[key].Products.length
										});
									}
									that.getView().byId("idProductsTable").setVisible(false);
									//
									MessageToast.show("Images classified and grouped into Categories!");
								} else {
									MessageToast.show("Images classified by SAP Leonardo!");
								}
								//
								that.getView().getModel().setData(that.aImgList);
								//
							}

						}
					});
					//Sending request
					xhr.send(data);
				});
			}
		},
		convertImgToDataURLviaCanvas: function(imageKey, url, callback, outputFormat) {
				var img = new Image();
				img.crossOrigin = 'Anonymous';
				img.onload = function() {
					var canvas = document.createElement('CANVAS');
					var ctx = canvas.getContext('2d');
					var dataURL;
					canvas.height = this.height;
					canvas.width = this.width;
					ctx.drawImage(this, 0, 0);
					dataURL = canvas.toDataURL(outputFormat);
					callback(imageKey, dataURL);
					canvas = null;
				};
				img.src = url;
			}
		/*,
		convertFileToDataURLviaFileReader: function(url, callback) {
			var xhr = new XMLHttpRequest();
			xhr.onload = function() {
				var reader = new FileReader();
				reader.onloadend = function() {
					callback(reader.result);
				}
				reader.readAsDataURL(xhr.response);
			};
			xhr.open('GET', url);
			xhr.responseType = 'blob';
			xhr.send();
		}*/
	});
});