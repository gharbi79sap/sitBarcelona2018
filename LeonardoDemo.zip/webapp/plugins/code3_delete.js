var sSearchString = this.getView().byId("searchString").getValue();
var sUrl = "https://www.googleapis.com/customsearch/v1?";
sUrl += "q=" + sSearchString;
sUrl += "&cx=XXXXXXXXXXXXXXXXX";
sUrl += "&key=YYYYYYYYYYYYYYYYYYYYYYY";
$.ajax({
	url: sUrl,
	jsonpCallback: 'processJSON',
	dataType: 'jsonp',
	success: function(result) {
		//Search Results from Google API
	},
	error: function(e) {
		//Handle errors
	}
});