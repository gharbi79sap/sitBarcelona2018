var oForm = new FormData();
oForm.append("files", oBlob, "image.jpg");

var xhr = new XMLHttpRequest();
xhr.withCredentials = false;

//Request method and API endpoint for API sandbox 
xhr.open("POST", "https://sandbox.api.sap.com/ml/prodimgclassifier/inference_sync");

//Request headers
xhr.setRequestHeader("Accept", "application/json");

//API Key for API Sandbox
xhr.setRequestHeader("APIKey", "XXXXXXXXXXXXXX");

//Event listener 
xhr.addEventListener("readystatechange", function() {
			if (this.readyState === this.DONE) {
				var aLeonardo = jQuery.parseJSON(this.responseText);
			}
		});