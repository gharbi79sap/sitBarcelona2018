//Helper function: Convert Image into base64
function convertImgIntoDataURL(googleURL, callback) {
	var oImg = new Image();
	oImg.crossOrigin = 'Anonymous';
	oImg.onload = function() {
		var oCanvas = document.createElement('CANVAS');
		var oCtx = canvas.getContext('2d');
		var oBlob;
		oCanvas.height = this.height;
		oCanvas.width = this.width;
		oCtx.drawImage(this, 0, 0);
		sDataURL = canvas.toDataURL();
		callback(dataURL);
	};
	oImg.src = googleURL;
}


//Convert Image into base64
var oBlob;
convertImgIntoDataURL(sGoogleURL, function(base64Img) {
	$("#img_id").attr("src", base64Img);
	oBlob = $("#img_id").imageBlob().blob();
});